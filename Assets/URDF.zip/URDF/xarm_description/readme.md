## xarm_description

​   This is the description package for xarm

### Unit test

> roslaunch xarm_description xarm7_rviz_display.launch



## launch

Load xarm7 model into parameter server

> xarm7_upload.launch

